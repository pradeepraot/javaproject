angular.module('tmobileApp',['ngRoute','ngResource','angularUtils.directives.dirPagination','appcontroller'])
/*.config(['$routeProvider',function($routeProvider) {
        $routeProvider

            // route           
            .when('/product', {
                templateUrl : 'partials/product.html',
                controller : 'appcontroller'
            });
		}]);*/

